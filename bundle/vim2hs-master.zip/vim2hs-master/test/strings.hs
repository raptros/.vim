main = putStr "hello\n"

bad = "hi there

good = "not part of bad"
